
DB_HOST = "127.0.0.1"
DB_USER = "root"
DB_PASSWORD = "nooreen@21"
DB_NAME = "women_handbag_db"
DB_PORT = 3306